# Legal Bot — Indian Legal Assistant Implementation Plan

Comprehensive implementation and completion plan for the Legal Bot project, preserving existing UI, pages, routes, and data models while activating real-time chat persistence, dual-mode Supabase/local storage, hybrid AI legal intelligence, and document analysis.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural decisions were confirmed in Phase 1 and govern the implementation:

- **Confirmed Decision 1 (Persistence Strategy)**: Dual-mode architecture. When Supabase environment variables (`VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`) are present, the app connects directly to Supabase with Row Level Security. When unconfigured or offline, the app seamlessly falls back to a mock/localStorage persistence layer so no features break.
- **Confirmed Decision 2 (Priority Focus)**: Core Chat Assistant (`Assistant.tsx`) with conversation history drawer, message persistence, instant statutory citations (BNS/IPC, BNSS/CrPC, BSA/IEA), and prompt suggestions.
- **Confirmed Decision 3 (Legal Intelligence)**: Hybrid model combining the deterministic local Indian statutory rules engine (`engine.ts`, `answerGenerator.ts`, `sections.ts`, `acts.ts`) with server-side Gemini 3.8 Flash enhancement for nuanced contextual reasoning, plain-language translation, and cross-statute synthesis.

---

## 1. Overview & Core Concept

- **What It Does**: Legal Bot (Nyaya Sahayak) is an Indian legal assistant web application providing accessible legal awareness, statutory lookups, intelligent Q&A on Indian Penal laws (Bharatiya Nyaya Sanhita / IPC, Bharatiya Nagarik Suraksha Sanhita / CrPC, Bharatiya Sakshya Adhiniyam / Evidence Act), document analysis, standard draft templates, legal aid directory, and verified lawyer consultation.
- **Target Audience / Persona**: Indian citizens seeking preliminary legal clarity, victims of cyber fraud or civil disputes needing immediate procedural guidance, small business owners drafting agreements, and practicing advocates looking for section cross-references.
- **Key Value**: Democratizes legal awareness in India with 24x7 guidance, structured section citations, emergency helpline access, and document risk assessments without expensive upfront consultations.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. *Legal Q&A Chat*: Citizen opens Assistant -> selects a quick topic (e.g., "Cheque Bounce Section 138", "Cyber Financial Fraud 1930 Helpline", "FIR Registration Rights") or types a scenario -> receives structured legal breakdown with relevant Sections, bailable/cognizable status, punishments, and immediate step-by-step actions -> conversation auto-saves to sidebar session history.
  2. *Document Risk Audit*: User uploads or pastes a contract/agreement -> parser extracts key clauses (Indemnity, Jurisdiction, Termination, Non-Compete) -> highlights ambiguous terms and missing safeguards -> assigns a clarity/risk score.
  3. *Lawyer Directory & Consult*: User filters lawyers by practice area (Criminal, Cyber, Family, Corporate) and city -> views Bar Council verification badge and practice experience -> submits consultation request.
  4. *Statutory & Constitutional Explorer*: Citizen searches through 500+ sections, Constitution Articles, and landmark Supreme Court precedents with real-time filtering and tabbed categorization.
- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Institutional Legal & Curatorial Rigor — clean, authoritative, trustworthy, and accessible.
  - *Color Palette*:
    - Canvas (60%): Clean white (`#FFFFFF`) / Deep Navy Slate (`#0B132B` in dark mode)
    - Structural Surfaces (30%): Warm parchment / soft limestone cards (`#F8F9FA` / `#111C38`), subtle hairline borders (`#E2E8F0` / `#1E293B`)
    - Accents (10%): Deep Judicial Navy (`#1E3A8A`), Rich Saffron/Gold accent (`#B45309`), Emergency Alert Crimson (`#DC2626`)
  - *Typography*:
    - Display / Headings: `Plus Jakarta Sans` / `Outfit` (clean geometric authority)
    - Body Prose: Highly legible reading face with `leading-relaxed` (65–75ch column widths)
    - Statutes & Citations: Tabular monospace accents (`font-mono tabular-nums`)
  - *Component Styling*:
    - Strictly unboxed metadata (using `·` separators)
    - Zero pill capsules for static text; interactive filter controls styled as segmented button groups
    - Hairline borders with single-elevation depth
- **Interactive Feedback & Motion**:
  - Fast feedback ($\le 200\text{ms}$) on query submission
  - Typing indicator during synthesis
  - Toast notifications for copied sections and saved chats
  - Graceful empty states and error boundaries

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Dual-Mode Supabase Client**:
  - *Chosen Approach*: Wrap the Supabase client in `src/lib/supabase.ts` with an abstraction layer that checks connection status. If environment variables are empty or network calls fail, gracefully route operations to reactive `localStorage` stores without throwing unhandled exceptions.
  - *Why*: Allows the app to run immediately in the AI Studio preview environment without requiring the user to execute SQL or enter private Supabase keys upfront, while remaining 100% ready for production Supabase credentials.
  - *Alternatives Considered*: Hard requirement on Supabase (would break the app preview immediately); pure mock (would require rewriting database integration later).
- **Decision 2: Hybrid AI & Statutory Engine**:
  - *Chosen Approach*: Use the comprehensive local Indian law database (`sections.ts`, `acts.ts`, `rights.ts`, `constitution.ts`, `engine.ts`) to extract exact statutory citations and criminal classifications, and enhance the output via a server-side Gemini 3.8 Flash proxy route (`/api/chat`) for conversational nuance and case analysis.
  - *Why*: Combines the absolute accuracy of Indian statutory law with the natural language versatility of modern LLMs, preventing hallucinations in legal citations.
  - *Alternatives Considered*: Client-side Gemini SDK (prohibited by system guidelines; leaks API keys); pure static engine (rigid responses).
- **Decision 3: Retaining All 21 Routes and Pages**:
  - *Chosen Approach*: Preserve the complete page directory (`Home`, `Assistant`, `Upload`, `Lawyers`, `JoinLawyer`, `Documents`, `Acts`, `Sections`, `Constitution`, `Rights`, `Courts`, `Cyber`, `Family`, `Labour`, `Property`, `Remedies`, `Evidence`, `Procedure`, `Precedents`, `LegalAid`, `Emergency`, `Deadlines`, `Sources`, `About`, `Disclaimer`).
  - *Why*: Directly preserves the user's extensive domain architecture, comprehensive Indian law content, and custom layout.

---

## 4. Technical Architecture & Data Strategy

### System Architecture Diagram

```
┌────────────────────────────────────────────────────────────────────────┐
│                              CLIENT BROWSER                            │
│                                                                        │
│  ┌──────────────────────┐  ┌────────────────────────────────────────┐  │
│  │   Navigation Shell   │  │              Page Views                │  │
│  │     (Layout.tsx)     │  │  - Assistant.tsx (Legal Q&A)           │  │
│  │  - Top Bar (3 zones) │  │  - Upload.tsx    (Doc Audit)           │  │
│  │  - Emergency Hotline │  │  - Lawyers.tsx   (Directory)           │  │
│  │  - Auth Panel Modal  │  │  - 18+ Statutory & Guide Pages         │  │
│  └──────────┬───────────┘  └───────────────────┬────────────────────┘  │
│             │                                  │                       │
│  ┌──────────▼──────────────────────────────────▼────────────────────┐  │
│  │                      State & Persistence Bridge                  │  │
│  │   - useChatSession()       - useAuthSession()                    │  │
│  │   - useDocumentStore()     - useLawyerDirectory()                │  │
│  └──────────────────┬──────────────────────────┬────────────────────┘  │
└─────────────────────┼──────────────────────────┼───────────────────────┘
                      │                          │
        [Dual-Mode Provider]             [Server API Proxy]
                      │                          │
         ┌────────────┴────────────┐             │
         ▼                         ▼             ▼
┌──────────────────┐      ┌──────────────────┐ ┌─────────────────────────┐
│ Local Store      │      │ Supabase Client  │ │ Express Server (port 3000)
│ (localStorage /  │ (or) │ (Postgres + Auth │ │  - POST /api/chat       │
│ reactive memory) │      │  + RLS Policies) │ │  - POST /api/analyze-doc│
└──────────────────┘      └──────────────────┘ └────────────┬────────────┘
                                                            │
                                                            ▼
                                                   ┌─────────────────┐
                                                   │ Google GenAI    │
                                                   │ Gemini 3.8 Flash│
                                                   └─────────────────┘
```

### Data Model & Entities

- **User / Session**: `id`, `email`, `role` (`citizen` | `lawyer` | `admin`), `full_name`, `created_at`
- **Conversation**: `id`, `user_id`, `title`, `created_at`, `updated_at`, `category`
- **Message**: `id`, `conversation_id`, `sender` (`user` | `assistant`), `content`, `sections_referenced`, `created_at`
- **Document Analysis**: `id`, `user_id`, `file_name`, `file_type`, `summary`, `risk_score`, `clauses`, `recommendations`, `created_at`
- **Lawyer Profile**: `id`, `name`, `bar_council_id`, `city`, `experience_years`, `specializations`, `phone`, `email`, `verified`, `rating`

### Interactive Component & State Mapping

1. **`Assistant.tsx`**:
   - Sidebar with session list, "New Chat" button, search filter, and delete action.
   - Main message viewport with streaming typing effect, copy-to-clipboard, statutory citation chips (links to `Sections.tsx`), and disclaimer banner.
   - Quick prompt pills below input: *"Arrest without warrant guidelines"*, *"Cheque bounce notice timeline"*, *"Cyber fraud recovery 1930"*, *"Divorce mutual consent process"*.
2. **`Upload.tsx`**:
   - Drag-and-drop file upload zone (supporting `.pdf`, `.docx`, `.txt`).
   - Client-side text extractor & clause parser.
   - Interactive Risk Meter (0–100) with color-coded breakdown of flagged clauses.
3. **`Lawyers.tsx` & `JoinLawyer.tsx`**:
   - Multi-criteria filter: City (Delhi, Mumbai, Bengaluru, etc.), Specialty (Criminal, Civil, Corporate, Cyber), Experience.
   - Verified Bar Council badge filter.
   - Contact lawyer modal generating a direct consultation ticket.
4. **`LegalBotAuthPanel.tsx`**:
   - Smooth login/register tabs with mock guest login option when Supabase is disconnected.

---

## 5. Execution Stages

- **Stage 1 (Codebase Hydration)**: Extract and integrate the existing `legal-bot` source files into the AI Studio root, reconciling Vite configs, Tailwind CSS styles, and dependencies.
- **Stage 2 (Dual-Mode Persistence)**: Update `src/lib/supabase.ts` with local fallback support to ensure zero runtime crashes regardless of connection status.
- **Stage 3 (Core Assistant & Chat)**: Implement conversation persistence, citation linkages, and the Express `/api/chat` endpoint powered by Gemini 3.8 Flash and the statutory engine.
- **Stage 4 (Document Analysis & Lawyers)**: Complete the document audit pipeline and lawyer verification workflow.
- **Stage 5 (Verification & Polish)**: Build and typecheck with `npm run build` and `compile_applet`.
