import { useState, useEffect } from 'react';
import { 
  UploadCloud, 
  FileText, 
  AlertTriangle, 
  CheckCircle2, 
  ShieldAlert, 
  FileCheck, 
  Loader2, 
  Scale, 
  ArrowRight,
  Info,
  Download,
  Copy,
  Check,
  Users,
  MapPin,
  ExternalLink,
  Calendar,
  Layers,
  Sparkles,
  BookOpen,
  HelpCircle,
  Clock,
  UserCheck
} from 'lucide-react';
import { 
  DocumentAnalysisResult, 
  FlaggedClause, 
  ExtractedFacts, 
  OfficialSource 
} from '../data/types';
import { getStoredLocation, UserLocationState } from '../data/location';
import { DocumentLawyerConsultModal } from '../components/DocumentLawyerConsultModal';
import { LocationSelectorModal } from '../components/LocationSelectorModal';

interface UploadProps {
  onNavigateTab?: (tab: string) => void;
}

export function Upload({ onNavigateTab }: UploadProps) {
  const [documentText, setDocumentText] = useState('');
  const [documentName, setDocumentName] = useState('');
  const [isExtracting, setIsExtracting] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<DocumentAnalysisResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [copiedAnalysis, setCopiedAnalysis] = useState(false);
  const [consultModalOpen, setConsultModalOpen] = useState(false);
  const [locationModalOpen, setLocationModalOpen] = useState(false);
  const [userLocation, setUserLocation] = useState<UserLocationState>(getStoredLocation());

  useEffect(() => {
    const handleLocationChange = (e: Event) => {
      const customEvt = e as CustomEvent<UserLocationState>;
      if (customEvt.detail) {
        setUserLocation(customEvt.detail);
      }
    };
    window.addEventListener('legalbot-location-changed', handleLocationChange);
    return () => window.removeEventListener('legalbot-location-changed', handleLocationChange);
  }, []);

  const sampleContracts = [
    {
      name: 'High-Risk Employment Agreement (Sample)',
      type: 'Employment Agreement',
      text: `EMPLOYMENT AND SERVICE AGREEMENT
This Agreement is entered into on 1st March 2026 by and between NexaTech Solutions Pvt Ltd ("Company") and Rahul Verma ("Employee").
1. TERM & COMMENCEMENT: The Employee's services commence on 1st April 2026 for a probationary period of 6 months.
2. EXCLUSIVITY & POST-TERMINATION NON-COMPETE: The Employee agrees that upon termination of this Agreement for any reason, the Employee shall not work for, consult with, or establish any competing business anywhere in India for a period of 3 (Three) years following termination.
3. UNILATERAL INDEMNITY: The Employee shall indemnify, hold harmless and defend the Company and its directors from any and all claims, financial losses, regulatory penalties, or customer disputes arising directly or indirectly during employment, irrespective of negligence.
4. TERMINATION AT WILL: The Company reserves the unilateral right to terminate the Employee immediately without cause and without any notice period or severance pay.
5. ARBITRATION & COSTS: All disputes shall be referred to a sole arbitrator appointed solely by the Company. All arbitration costs shall be borne entirely by the Employee.
6. JURISDICTION: This agreement shall be subject to the exclusive jurisdiction of courts outside the territory of India.`,
    },
    {
      name: 'Standard 11-Month Residential Rental Agreement (Sample)',
      type: 'Residential Rental Agreement',
      text: `RESIDENTIAL LEASE AGREEMENT
This Rent Agreement is made on 15th January 2026 between Ramesh Chandra ("Landlord") and Anita Sen ("Tenant").
1. TERM: The tenancy shall be for an 11-month period from 1st February 2026 to 31st December 2026.
2. RENT: Monthly rent of Rs. 28,000/- payable before the 5th of each calendar month into Landlord's bank account.
3. SECURITY DEPOSIT: Tenant has deposited an interest-free refundable deposit of Rs. 84,000/-. Deposit shall be refunded within 15 days of vacation after verifying utility bills.
4. NOTICE PERIOD: Either party may terminate with 1 month prior written notice.
5. LOCK-IN PERIOD: A lock-in period of 3 months applies from the commencement date.
6. UTILITIES: Electricity and water shall be paid directly by the Tenant as per meter readings.
7. GOVERNING LAW & JURISDICTION: Governed by the laws of India and civil courts of New Delhi.`,
    },
    {
      name: 'Mutual Non-Disclosure Agreement (Sample)',
      type: 'Non-Disclosure Agreement (NDA)',
      text: `MUTUAL NON-DISCLOSURE AGREEMENT
This Agreement is made on 10th February 2026 between Alpha Digital Ltd ("Disclosing Party") and Beta Ventures LLP ("Receiving Party").
1. PURPOSE: The parties wish to explore a potential strategic commercial partnership.
2. CONFIDENTIAL INFORMATION: Includes all technical, proprietary, and commercial information disclosed in written or digital form.
3. EXCLUSIONS: Information publicly known, independently developed, or rightfully obtained from third parties is excluded.
4. PERPETUAL OBLIGATION: The Receiving Party shall protect Confidential Information indefinitely with no sunset expiration date.
5. GOVERNING LAW & ARBITRATION: Governed by laws of India. Any dispute shall be resolved through arbitration under the Arbitration and Conciliation Act 1996 seated in Mumbai.`,
    },
  ];

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setErrorMsg(null);
    setAnalysisResult(null);

    // 1. Validate file size (10MB)
    if (file.size > 10 * 1024 * 1024) {
      setErrorMsg('File size exceeds the 10MB limit. Please upload a smaller document.');
      return;
    }

    // 2. Validate file type
    const lowerName = file.name.toLowerCase();
    const isPdf = lowerName.endsWith('.pdf') || file.type === 'application/pdf';
    const isDocx = lowerName.endsWith('.docx') || lowerName.endsWith('.doc') || file.type.includes('wordprocessingml');
    const isTxt = lowerName.endsWith('.txt') || file.type === 'text/plain';

    if (!isPdf && !isDocx && !isTxt) {
      setErrorMsg('Unsupported file format. Please upload a PDF (.pdf), Word document (.docx), or plain text file (.txt).');
      return;
    }

    setDocumentName(file.name);
    setIsExtracting(true);

    try {
      if (isTxt) {
        const text = await file.text();
        if (!text.trim()) {
          setErrorMsg('The uploaded text file is empty. Please provide a document with text.');
        } else {
          setDocumentText(text.trim());
        }
        setIsExtracting(false);
        return;
      }

      // For PDF and DOCX, use the server-side extraction endpoint
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const base64Data = (reader.result as string) || '';
          const response = await fetch('/api/extract-document-text', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              base64: base64Data,
              filename: file.name,
              mimeType: file.type,
            }),
          });

          const data = await response.json();
          if (response.ok && data.text) {
            setDocumentText(data.text);
          } else {
            setErrorMsg(
              data.error ||
                'Unable to extract readable text. The document may be scanned (image-only), password-protected, or corrupted. Please provide a searchable file or paste the text directly.'
            );
          }
        } catch (fetchErr) {
          console.error('Error during file extraction:', fetchErr);
          setErrorMsg('Failed to process file on server. Please try pasting the text directly into the audit box.');
        } finally {
          setIsExtracting(false);
        }
      };

      reader.onerror = () => {
        setIsExtracting(false);
        setErrorMsg('Failed to read file from disk. Please try again or paste text directly.');
      };

      reader.readAsDataURL(file);
    } catch (err) {
      setIsExtracting(false);
      setErrorMsg('Error processing file. Please paste text directly.');
      console.error(err);
    }
  };

  const handleRunAudit = async () => {
    if (!documentText.trim()) {
      setErrorMsg('Please paste or upload document text to audit.');
      return;
    }

    setIsAnalyzing(true);
    setErrorMsg(null);

    try {
      const response = await fetch('/api/analyze-document', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          documentText,
          documentName: documentName || 'Legal Document Audit',
        }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data.analysis && data.analysis.summary) {
          setAnalysisResult(formatOrEnrichResult(data.analysis, documentText, documentName));
        } else {
          runLocalRuleAudit(documentText, documentName);
        }
      } else {
        // Fallback local statutory audit
        runLocalRuleAudit(documentText, documentName);
      }
    } catch {
      runLocalRuleAudit(documentText, documentName);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const formatOrEnrichResult = (
    raw: any,
    text: string,
    docTitle: string
  ): DocumentAnalysisResult => {
    const lower = text.toLowerCase();
    
    // Ensure extractedFacts conforms to schema
    const extractedFacts: ExtractedFacts = {
      documentType: raw.extractedFacts?.documentType || raw.documentType || detectDocType(text, docTitle),
      subject: raw.extractedFacts?.subject || raw.subject || 'Contractual rights, duties, and covenants',
      parties: raw.extractedFacts?.parties || extractPartiesFromText(text),
      importantDates: raw.extractedFacts?.importantDates || extractDatesFromText(text),
      keyObligations: raw.extractedFacts?.keyObligations || extractObligationsFromText(text),
      importantClauses: raw.extractedFacts?.importantClauses || extractKeyClausesFromText(text),
    };

    const officialSources: OfficialSource[] = raw.officialSources?.length
      ? raw.officialSources
      : [
          {
            title: 'Indian Contract Act, 1872',
            statute: 'Act No. 9 of 1872',
            url: 'https://www.indiacode.nic.in/handle/123456789/2187',
            relevance: 'Governs agreement validity, consideration, and Section 27 void restrains.',
          },
          {
            title: 'Arbitration and Conciliation Act, 1996',
            statute: 'Act No. 26 of 1996',
            url: 'https://www.indiacode.nic.in/handle/123456789/1978',
            relevance: 'Section 12(5) governs independence of arbitrators and neutral appointment.',
          },
        ];

    return {
      summary: raw.summary || 'Comprehensive legal review of the provided agreement.',
      plainLanguageExplanation:
        raw.plainLanguageExplanation ||
        'This agreement creates binding rights and financial duties. It includes specific provisions that may limit your future employment or require you to pay damages unless amended.',
      documentType: raw.documentType || extractedFacts.documentType,
      subject: raw.subject || extractedFacts.subject,
      riskScore: typeof raw.riskScore === 'number' ? raw.riskScore : 45,
      riskLevel: raw.riskLevel || 'Medium',
      governingLawCompliance: raw.governingLawCompliance || 'Evaluated under Indian legal jurisdiction.',
      extractedFacts,
      flaggedClauses: raw.flaggedClauses || [],
      missingProtections: raw.missingProtections || [
        'Mutual limitation of liability cap',
        'Standard Force Majeure relief clause',
        'Balanced statutory dispute resolution forum',
      ],
      positiveAspects: raw.positiveAspects || ['Clearly defines the roles and execution timeline.'],
      recommendedNextSteps: raw.recommendedNextSteps || [
        'Request mutual revision of any flagged high-risk clauses prior to signing.',
        'Ensure proper Non-Judicial Stamp Duty is paid under the applicable State Stamp Act.',
        'Consult a registered advocate to formalize necessary redline amendments.',
      ],
      officialSources,
    };
  };

  const detectDocType = (text: string, title: string): string => {
    const t = (text + ' ' + title).toLowerCase();
    if (t.includes('rent') || t.includes('lease') || t.includes('tenan')) return 'Residential Rental Agreement';
    if (t.includes('employ') || t.includes('service agreement') || t.includes('salary')) return 'Employment Agreement';
    if (t.includes('nda') || t.includes('non-disclosure') || t.includes('confidential')) return 'Non-Disclosure Agreement (NDA)';
    if (t.includes('vendor') || t.includes('master service') || t.includes('supplier')) return 'Commercial Vendor Contract';
    if (t.includes('loan') || t.includes('promissory') || t.includes('borrower')) return 'Loan & Promissory Agreement';
    return 'General Commercial Agreement';
  };

  const extractPartiesFromText = (text: string) => {
    const parties = [];
    if (text.includes('Landlord') || text.includes('Lessor')) parties.push({ role: 'Lessor / Landlord', name: 'Landlord party' });
    if (text.includes('Tenant') || text.includes('Lessee')) parties.push({ role: 'Lessee / Tenant', name: 'Tenant party' });
    if (text.includes('Company') || text.includes('Employer')) parties.push({ role: 'Employer / Company', name: 'First Party (Employer)' });
    if (text.includes('Employee')) parties.push({ role: 'Employee', name: 'Second Party (Employee)' });
    if (text.includes('Disclosing Party')) parties.push({ role: 'Disclosing Party', name: 'Party Disclosing Proprietary Info' });
    if (text.includes('Receiving Party')) parties.push({ role: 'Receiving Party', name: 'Party Receiving Proprietary Info' });
    if (parties.length === 0) parties.push({ role: 'Contracting Parties', name: 'Parties executing draft' });
    return parties;
  };

  const extractDatesFromText = (text: string) => {
    const dates = [];
    const dateMatch = text.match(/\b\d{1,2}(?:st|nd|rd|th)?\s+(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{4}\b/i);
    if (dateMatch) {
      dates.push({ label: 'Execution / Effective Date', dateOrPeriod: dateMatch[0] });
    }
    if (text.includes('11-month') || text.includes('11 month')) {
      dates.push({ label: 'Term Duration', dateOrPeriod: '11 Months' });
    }
    if (text.toLowerCase().includes('notice')) {
      dates.push({ label: 'Termination Notice Period', dateOrPeriod: '30 Days / 1 Month prior notice' });
    }
    if (dates.length === 0) {
      dates.push({ label: 'Effective Term', dateOrPeriod: 'As specified in agreement schedule' });
    }
    return dates;
  };

  const extractObligationsFromText = (text: string) => {
    const obs: string[] = [];
    const lower = text.toLowerCase();
    if (lower.includes('rent')) obs.push('Obligation to pay monthly rent before the stipulated calendar due date.');
    if (lower.includes('security deposit')) obs.push('Obligation to deposit interest-free refundable security deposit and return upon vacation.');
    if (lower.includes('confidential')) obs.push('Duty to protect disclosed proprietary trade secrets and technical data.');
    if (lower.includes('indemnif')) obs.push('Contractual obligation to hold harmless and indemnify opposing party.');
    if (obs.length === 0) obs.push('Performance of duties and covenants outlined across clauses.');
    return obs;
  };

  const extractKeyClausesFromText = (text: string) => {
    const clauses = [];
    const lower = text.toLowerCase();
    if (lower.includes('non-compete')) {
      clauses.push({
        clauseTitle: 'Exclusivity & Non-Compete',
        originalTextSnippet: 'Prohibits engaging in competing business post-termination',
        purpose: 'Restricts post-employment commercial engagement',
      });
    }
    if (lower.includes('indemnif')) {
      clauses.push({
        clauseTitle: 'Indemnification Clause',
        originalTextSnippet: 'Indemnifies and defends the company against losses or penalties',
        purpose: 'Allocates financial liability between signatory parties',
      });
    }
    if (lower.includes('arbitrat')) {
      clauses.push({
        clauseTitle: 'Dispute Resolution / Arbitration',
        originalTextSnippet: 'Disputes referred to arbitration',
        purpose: 'Defines adjudicatory forum outside civil court trial',
      });
    }
    if (clauses.length === 0) {
      clauses.push({
        clauseTitle: 'General Covenants',
        originalTextSnippet: text.slice(0, 100) + '...',
        purpose: 'Defines operational terms and execution parameters',
      });
    }
    return clauses;
  };

  // Local fallback rule-based analyzer conforming to complete schema
  const runLocalRuleAudit = (text: string, title: string) => {
    const lower = text.toLowerCase();
    const flagged: FlaggedClause[] = [];
    let score = 25;

    // Check non-compete
    if (lower.includes('non-compete') || lower.includes('competing business')) {
      flagged.push({
        clauseTitle: 'Post-Termination Non-Compete Restriction',
        severity: 'High',
        issue: 'Agreements in restraint of trade are void under Section 27 of the Indian Contract Act, 1872.',
        recommendation: 'Post-employment non-compete covenants are legally unenforceable in India. Replace with a narrow confidentiality and non-solicitation clause.',
        relevantLaw: 'Section 27, Indian Contract Act 1872; Percept D\'Mark v. Zaheer Khan (2006)',
      });
      score += 35;
    }

    // Check unilateral indemnity
    if (lower.includes('indemnify') && (lower.includes('solely') || lower.includes('unilateral') || lower.includes('irrespective') || lower.includes('directors'))) {
      flagged.push({
        clauseTitle: 'Unilateral & Unlimited Indemnification Exposure',
        severity: 'High',
        issue: 'Exposes one party to uncapped financial liabilities without mutual indemnity or aggregate liability cap.',
        recommendation: 'Cap maximum aggregate liability to fees received or a reasonable insurance cap, and exclude indirect or consequential damages.',
        relevantLaw: 'Section 73, Indian Contract Act 1872',
      });
      score += 25;
    }

    // Check termination without notice
    if (lower.includes('without cause') && (lower.includes('without any notice') || lower.includes('immediately'))) {
      flagged.push({
        clauseTitle: 'Immediate Termination Without Notice or Severance',
        severity: 'Medium',
        issue: 'Deprives signatory of customary 30–60 day transition period.',
        recommendation: 'Insert mandatory reciprocal 30-day written notice period for convenience termination.',
        relevantLaw: 'Principles of Natural Justice & Commercial Good Faith',
      });
      score += 15;
    }

    // Check unilateral arbitrator appointment
    if (lower.includes('appointed solely') || lower.includes('sole arbitrator appointed by') || lower.includes('solely by the company')) {
      flagged.push({
        clauseTitle: 'Unilateral Appointment of Sole Arbitrator',
        severity: 'High',
        issue: 'Violates Supreme Court ruling in Perkins Eastman (2019) and Section 12(5) of Arbitration & Conciliation Act 1996.',
        recommendation: 'Mandate mutual consent for appointing arbitrator or institutional appointment through High Court / DIAC.',
        relevantLaw: 'Perkins Eastman Architects v. HSCC (India) Ltd (2019); Section 12(5) Arbitration Act',
      });
      score += 20;
    }

    // Check foreign jurisdiction
    if (lower.includes('outside the territory of india') || lower.includes('foreign court')) {
      flagged.push({
        clauseTitle: 'Ouster of Indian Court Jurisdiction',
        severity: 'High',
        issue: 'Indian parties contracting within India cannot confer exclusive jurisdiction on foreign courts to circumvent Indian laws.',
        recommendation: 'Restructure jurisdiction to courts where cause of action arose or High Court in India.',
        relevantLaw: 'Section 28, Indian Contract Act 1872; Modi Entertainment Network (2003)',
      });
      score += 20;
    }

    const finalScore = Math.min(score, 95);
    const riskLevel: 'Low' | 'Medium' | 'High' = finalScore > 65 ? 'High' : finalScore > 40 ? 'Medium' : 'Low';
    const docType = detectDocType(text, title);

    const result: DocumentAnalysisResult = {
      documentType: docType,
      subject: `Audit of ${docType} under Indian statutory frameworks`,
      summary: `Audited legal draft against Indian Contract Act 1872 and commercial jurisprudence. Identified ${flagged.length} potential legal exposures.`,
      plainLanguageExplanation: `This agreement establishes legal duties for the parties. Important safeguards regarding liability and post-termination restrictions require review before signing.`,
      riskScore: finalScore,
      riskLevel,
      governingLawCompliance: 'Evaluated under Indian Contract Act 1872, Arbitration Act 1996, and Transfer of Property Act 1882.',
      extractedFacts: {
        documentType: docType,
        subject: `Terms and conditions in ${title || 'Legal Document'}`,
        parties: extractPartiesFromText(text),
        importantDates: extractDatesFromText(text),
        keyObligations: extractObligationsFromText(text),
        importantClauses: extractKeyClausesFromText(text),
      },
      flaggedClauses: flagged,
      missingProtections: [
        'Mutual limitation of liability cap',
        'Standard Force Majeure protection clause',
        'Balanced statutory dispute resolution forum',
      ],
      positiveAspects: [
        'Execution date and party identities are clearly identifiable.',
        'Primary consideration and service scope are articulated.',
      ],
      recommendedNextSteps: [
        'Request mutual revision of any flagged high-risk clauses prior to signing.',
        'Verify applicable Non-Judicial Stamp Duty under State Stamp Act.',
        'Consult a verified advocate in your city for formal redline drafting.',
      ],
      officialSources: [
        {
          title: 'Indian Contract Act, 1872',
          statute: 'Act No. 9 of 1872',
          url: 'https://www.indiacode.nic.in/handle/123456789/2187',
          relevance: 'Section 27 renders agreements in restraint of trade void.',
        },
        {
          title: 'Arbitration and Conciliation Act, 1996',
          statute: 'Act No. 26 of 1996',
          url: 'https://www.indiacode.nic.in/handle/123456789/1978',
          relevance: 'Section 12(5) bars unilateral appointment of sole arbitrators.',
        },
      ],
    };

    setAnalysisResult(result);
  };

  const generateReportText = (): string => {
    if (!analysisResult) return '';
    const r = analysisResult;
    return `=====================================================
LEGAL BOT — INDIAN CONTRACT & DOCUMENT AUDIT REPORT
Document: ${documentName || 'Document Audit'}
Generated: ${new Date().toLocaleDateString('en-IN', { dateStyle: 'full' })}
Risk Score: ${r.riskScore}/100 (${r.riskLevel} Risk)
=====================================================

1. DOCUMENT SUMMARY
${r.summary}

Plain Language Explanation:
${r.plainLanguageExplanation}

-----------------------------------------------------
2. EXTRACTED FACTS (FROM TEXT)
Document Type: ${r.extractedFacts?.documentType}
Subject: ${r.extractedFacts?.subject}

Identified Parties:
${r.extractedFacts?.parties?.map((p) => `- ${p.role}: ${p.name}`).join('\n') || 'None specified'}

Important Dates & Deadlines:
${r.extractedFacts?.importantDates?.map((d) => `- ${d.label}: ${d.dateOrPeriod}`).join('\n') || 'None specified'}

Key Obligations:
${r.extractedFacts?.keyObligations?.map((o) => `- ${o}`).join('\n') || 'None specified'}

-----------------------------------------------------
3. FLAGGED LEGAL ISSUES & RISKS (${r.flaggedClauses?.length || 0})
${r.flaggedClauses?.map((c, idx) => `
[Clause ${idx + 1}] ${c.clauseTitle} (Severity: ${c.severity})
Issue: ${c.issue}
Recommended Redline: ${c.recommendation}
Relevant Law: ${c.relevantLaw || 'Indian Contract Act 1872'}
`).join('\n') || 'No high-risk clauses flagged.'}

-----------------------------------------------------
4. MISSING CLAUSES & SAFEGUARDS
${r.missingProtections?.map((p) => `- ${p}`).join('\n') || 'None'}

-----------------------------------------------------
5. RECOMMENDED NEXT STEPS
${r.recommendedNextSteps?.map((s) => `- ${s}`).join('\n') || 'None'}

-----------------------------------------------------
6. OFFICIAL SOURCES & STATUTORY CITATIONS
${r.officialSources?.map((s) => `- ${s.title} (${s.statute}): ${s.relevance}\n  Link: ${s.url}`).join('\n\n') || 'India Code (https://www.indiacode.nic.in)'}

-----------------------------------------------------
DISCLAIMER: This preliminary audit is for educational and legal risk awareness under Indian law. It does not replace registered advocate counsel.
`;
  };

  const handleCopyAnalysis = () => {
    const report = generateReportText();
    navigator.clipboard.writeText(report);
    setCopiedAnalysis(true);
    setTimeout(() => setCopiedAnalysis(false), 2000);
  };

  const handleDownloadAnalysis = () => {
    const report = generateReportText();
    const blob = new Blob([report], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `LegalBot_Audit_${(documentName || 'Document').replace(/\.[^/.]+$/, '')}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
            <FileCheck className="w-7 h-7 text-emerald-600 dark:text-emerald-400" />
            <span>Document Upload & Legal Audit</span>
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-3xl">
            Upload PDF, DOCX, or TXT agreements to extract readable text, identify risks under Indian law, separate facts from legal interpretations, and connect with verified advocates.
          </p>
        </div>

        {/* Location badge in header */}
        <button
          onClick={() => setLocationModalOpen(true)}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:border-blue-500 transition-colors shadow-2xs self-start sm:self-center"
        >
          <MapPin className="w-3.5 h-3.5 text-blue-600 shrink-0" />
          <span>Location: {userLocation.city}, {userLocation.state}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Upload & Input Panel */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <UploadCloud className="w-5 h-5 text-blue-600" />
              <span>Upload Document (PDF, DOCX, TXT)</span>
            </h2>

            {/* Dropzone */}
            <label className="border-2 border-dashed border-slate-200 dark:border-slate-700 hover:border-blue-500 rounded-xl p-6 flex flex-col items-center justify-center cursor-pointer bg-slate-50/50 dark:bg-slate-800/40 transition-colors group">
              <FileText className="w-9 h-9 text-slate-400 group-hover:text-blue-600 transition-colors mb-2" />
              <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 text-center">
                Click to browse or drop PDF, DOCX, or TXT file
              </span>
              <span className="text-[11px] text-slate-400 mt-1 text-center">
                Max 10MB · Encrypted client processing · Searchable text
              </span>
              <input
                type="file"
                accept=".pdf,.docx,.doc,.txt,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>

            {isExtracting && (
              <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-xs text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-900 flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin shrink-0" />
                <span>Extracting readable text from document...</span>
              </div>
            )}

            {documentName && !isExtracting && (
              <div className="text-xs text-emerald-700 dark:text-emerald-400 font-medium flex items-center justify-between p-2.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/50">
                <div className="flex items-center gap-1.5 truncate">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="truncate">Active: {documentName}</span>
                </div>
                <button
                  onClick={() => {
                    setDocumentName('');
                    setDocumentText('');
                    setAnalysisResult(null);
                  }}
                  className="text-slate-400 hover:text-red-500 text-[11px] shrink-0 ml-2"
                >
                  Clear
                </button>
              </div>
            )}

            {/* Paste Text Area */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Or Paste Agreement Text Directly
                </label>
                <span className="text-[11px] text-slate-400 font-mono">
                  {documentText.length.toLocaleString()} characters
                </span>
              </div>
              <textarea
                rows={8}
                value={documentText}
                onChange={(e) => setDocumentText(e.target.value)}
                placeholder="Paste contract clauses, employment agreement, rental deed, NDA, or loan terms here..."
                className="w-full p-3 text-xs font-mono rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-blue-600 leading-relaxed"
              />
            </div>

            {/* Pre-loaded Sample Selector */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
              <span className="text-[11px] text-slate-500 font-medium block mb-2">
                Try Pre-loaded Test Drafts:
              </span>
              <div className="flex flex-col gap-1.5">
                {sampleContracts.map((s, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setDocumentName(s.name);
                      setDocumentText(s.text);
                      setErrorMsg(null);
                    }}
                    className="p-2 rounded-lg text-left text-xs bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 transition-colors border border-slate-200 dark:border-slate-700/60 flex items-center justify-between"
                  >
                    <span className="font-medium truncate">{s.name}</span>
                    <span className="text-[10px] text-blue-600 uppercase font-semibold shrink-0 ml-2">Load</span>
                  </button>
                ))}
              </div>
            </div>

            {errorMsg && (
              <div className="p-3.5 rounded-xl bg-red-50 dark:bg-red-950/40 text-xs text-red-700 dark:text-red-300 border border-red-200 dark:border-red-900/60 space-y-1">
                <div className="font-semibold flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>Processing Notice</span>
                </div>
                <p className="text-[11px] leading-relaxed">{errorMsg}</p>
              </div>
            )}

            <button
              onClick={handleRunAudit}
              disabled={isAnalyzing || isExtracting || !documentText.trim()}
              className="w-full py-3 rounded-xl bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 text-white font-semibold text-sm transition-colors flex items-center justify-center gap-2 disabled:opacity-40 shadow-xs cursor-pointer"
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Auditing Clauses under Indian Law...</span>
                </>
              ) : (
                <>
                  <Scale className="w-4 h-4" />
                  <span>Run Legal Risk Audit</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right: Detailed Audit Results Panel */}
        <div className="lg:col-span-7 space-y-6">
          {analysisResult ? (
            <div className="space-y-6 animate-in fade-in">
              {/* Top Banner: Composite Risk Score + Quick Actions */}
              <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <span className="text-[11px] uppercase tracking-wider font-bold text-slate-400">
                      Detected Classification
                    </span>
                    <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
                      {analysisResult.documentType}
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {analysisResult.subject}
                    </p>
                  </div>

                  <div className="flex items-center gap-4 sm:border-l sm:border-slate-100 dark:sm:border-slate-800 sm:pl-6 shrink-0">
                    <div>
                      <div className="text-[11px] text-slate-400 font-medium">Composite Risk</div>
                      <div className="text-3xl font-extrabold text-slate-900 dark:text-white tabular-nums">
                        {analysisResult.riskScore}
                        <span className="text-xs font-normal text-slate-400"> / 100</span>
                      </div>
                    </div>
                    <span
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold uppercase tracking-wider ${
                        analysisResult.riskLevel === 'High'
                          ? 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300 border border-red-200'
                          : analysisResult.riskLevel === 'Medium'
                          ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border border-amber-200'
                          : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-200'
                      }`}
                    >
                      {analysisResult.riskLevel} Risk
                    </span>
                  </div>
                </div>

                {/* Toolbar: Copy Analysis, Download Analysis, and Lawyer Consult Button */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleCopyAnalysis}
                      className="py-1.5 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 text-slate-700 dark:text-slate-200 text-xs font-medium transition-colors flex items-center gap-1.5"
                    >
                      {copiedAnalysis ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedAnalysis ? 'Copied' : 'Copy Analysis'}</span>
                    </button>
                    <button
                      onClick={handleDownloadAnalysis}
                      className="py-1.5 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 text-slate-700 dark:text-slate-200 text-xs font-medium transition-colors flex items-center gap-1.5"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download Report</span>
                    </button>
                  </div>

                  {/* Connect to Nearby Lawyer CTA */}
                  <button
                    onClick={() => setConsultModalOpen(true)}
                    className="py-2 px-4 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold transition-colors flex items-center gap-2 shadow-xs cursor-pointer ml-auto"
                  >
                    <UserCheck className="w-4 h-4" />
                    <span>Consult a Nearby Lawyer About This Document</span>
                  </button>
                </div>
              </div>

              {/* SECTION 1: Document Summary & Plain-Language Explanation */}
              <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
                <div className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-blue-700 dark:text-blue-400" />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white">
                    Document Summary & Citizen Plain-Language Guide
                  </h3>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 space-y-2 text-xs">
                  <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                    Executive Summary:
                  </span>
                  <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                    {analysisResult.summary}
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-blue-50/60 dark:bg-blue-950/30 border border-blue-100 dark:border-blue-900/40 space-y-2 text-xs">
                  <span className="font-semibold text-blue-900 dark:text-blue-200 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                    <span>What This Means For You (Simple Language):</span>
                  </span>
                  <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                    {analysisResult.plainLanguageExplanation}
                  </p>
                </div>
              </div>

              {/* SECTION 2: EXTRACTED FACTS (Clearly distinguished from AI interpretations) */}
              <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <Layers className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                    <div>
                      <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white">
                        Extracted Document Facts
                      </h3>
                      <p className="text-[11px] text-slate-400">
                        Verbatim terms directly recorded in the draft text (Non-AI Generated)
                      </p>
                    </div>
                  </div>
                  <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                    Extracted Facts
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  {/* Parties */}
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 space-y-1.5">
                    <span className="font-bold text-slate-700 dark:text-slate-300 block">
                      Identified Contracting Parties:
                    </span>
                    <ul className="space-y-1 text-slate-600 dark:text-slate-400 text-[11px]">
                      {analysisResult.extractedFacts?.parties?.map((p, idx) => (
                        <li key={idx} className="flex items-start gap-1.5">
                          <span className="font-semibold text-slate-800 dark:text-slate-200">• {p.role}:</span>
                          <span>{p.name}</span>
                        </li>
                      )) || <li>None stated in text</li>}
                    </ul>
                  </div>

                  {/* Important Dates */}
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 space-y-1.5">
                    <span className="font-bold text-slate-700 dark:text-slate-300 block">
                      Important Dates & Timelines:
                    </span>
                    <ul className="space-y-1 text-slate-600 dark:text-slate-400 text-[11px]">
                      {analysisResult.extractedFacts?.importantDates?.map((d, idx) => (
                        <li key={idx} className="flex items-start gap-1.5">
                          <span className="font-semibold text-slate-800 dark:text-slate-200">• {d.label}:</span>
                          <span>{d.dateOrPeriod}</span>
                        </li>
                      )) || <li>None stated in text</li>}
                    </ul>
                  </div>
                </div>

                {/* Key Obligations */}
                {analysisResult.extractedFacts?.keyObligations?.length > 0 && (
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 space-y-1.5 text-xs">
                    <span className="font-bold text-slate-700 dark:text-slate-300 block">
                      Primary Contractual Obligations:
                    </span>
                    <ul className="space-y-1 text-slate-600 dark:text-slate-400 text-[11px]">
                      {analysisResult.extractedFacts.keyObligations.map((o, idx) => (
                        <li key={idx} className="flex items-start gap-1.5">
                          <span className="text-blue-600">✓</span>
                          <span>{o}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* SECTION 3: FLAGGED LEGAL ISSUES & RISKS (AI Interpretation) */}
              <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <ShieldAlert className="w-5 h-5 text-red-600 dark:text-red-400" />
                    <div>
                      <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white">
                        Flagged Legal Issues & Risks ({analysisResult.flaggedClauses?.length || 0})
                      </h3>
                      <p className="text-[11px] text-slate-400">
                        AI Statutory Interpretation under Indian Law & Contract Jurisprudence
                      </p>
                    </div>
                  </div>
                  <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded bg-red-50 dark:bg-red-950 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-800">
                    Legal Interpretation
                  </span>
                </div>

                <div className="space-y-3">
                  {analysisResult.flaggedClauses?.map((clause, idx) => (
                    <div
                      key={idx}
                      className="p-4 rounded-xl bg-red-50/50 dark:bg-red-950/20 border border-red-200 dark:border-red-900/40 text-xs space-y-2"
                    >
                      <div className="flex items-center justify-between font-bold text-red-900 dark:text-red-200">
                        <span>{clause.clauseTitle}</span>
                        <span className="text-[10px] uppercase px-2 py-0.5 rounded bg-red-200 dark:bg-red-900/60 text-red-800 dark:text-red-300 font-semibold">
                          {clause.severity} Severity
                        </span>
                      </div>

                      <p className="text-red-900 dark:text-red-300 leading-relaxed">
                        <strong>Potential Legal Issue:</strong> {clause.issue}
                      </p>

                      <div className="p-3 rounded-lg bg-white dark:bg-slate-900 border border-red-100 dark:border-red-900/30 text-slate-800 dark:text-slate-200 leading-relaxed">
                        <strong className="text-blue-700 dark:text-blue-400">Recommended Redline / Action:</strong>{' '}
                        {clause.recommendation}
                      </div>

                      {clause.relevantLaw && (
                        <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                          <Scale className="w-3.5 h-3.5 text-blue-600" />
                          <span>Statutory Authority: {clause.relevantLaw}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* SECTION 4: Missing Safeguards & Next Steps */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Missing Safeguards */}
                <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-amber-500" />
                    <span>Missing Clauses & Safeguards</span>
                  </h3>
                  <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
                    {analysisResult.missingProtections?.map((p, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-amber-500 font-bold">•</span>
                        <span>{p}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Recommended Next Steps */}
                <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Recommended Next Steps</span>
                  </h3>
                  <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
                    {analysisResult.recommendedNextSteps?.map((step, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-emerald-600 font-bold">{idx + 1}.</span>
                        <span>{step}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* SECTION 5: Official Statutory Sources & India Code Links */}
              <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4 text-blue-600" />
                  <span>Official Sources & Statutory Links</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  {analysisResult.officialSources?.map((src, idx) => (
                    <a
                      key={idx}
                      href={src.url}
                      target="_blank"
                      rel="noreferrer"
                      className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-blue-500 bg-slate-50/50 dark:bg-slate-800/40 transition-colors block group"
                    >
                      <div className="flex items-center justify-between font-bold text-slate-900 dark:text-white group-hover:text-blue-600">
                        <span>{src.title}</span>
                        <ExternalLink className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-600" />
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">{src.statute}</div>
                      <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                        {src.relevance}
                      </p>
                    </a>
                  ))}
                </div>
              </div>

              {/* Connect to Nearby Lawyer Banner (Bottom) */}
              <div className="p-6 rounded-2xl bg-gradient-to-r from-blue-900 to-indigo-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-md">
                <div>
                  <span className="text-blue-300 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
                    <UserCheck className="w-4 h-4" />
                    <span>Advocate Connection</span>
                  </span>
                  <h4 className="text-lg font-extrabold text-white mt-1">
                    Ready to resolve these flagged clauses?
                  </h4>
                  <p className="text-xs text-blue-100 max-w-xl mt-0.5 leading-relaxed">
                    Connect directly with verified advocates practicing in {userLocation.city} specializing in {analysisResult.documentType}. Your raw document is never transmitted without explicit consent.
                  </p>
                </div>

                <button
                  onClick={() => setConsultModalOpen(true)}
                  className="py-2.5 px-5 rounded-xl bg-white text-blue-950 font-bold text-xs hover:bg-blue-50 transition-colors shadow-xs whitespace-nowrap self-start sm:self-center"
                >
                  Consult Nearby Advocate
                </button>
              </div>
            </div>
          ) : (
            /* Empty State */
            <div className="h-full min-h-[440px] rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center p-8 text-center bg-white/40 dark:bg-slate-900/40 space-y-3">
              <FileCheck className="w-14 h-14 text-slate-300 dark:text-slate-700" />
              <div className="max-w-md space-y-1">
                <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">
                  Comprehensive Legal Audit Ready
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  Upload a PDF, DOCX, or TXT file or load a pre-loaded agreement on the left. The auditor will extract clauses, flag void terms under Indian statutes, separate facts from interpretations, and connect you with verified advocates.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Connect Lawyer Modal */}
      {analysisResult && (
        <DocumentLawyerConsultModal
          isOpen={consultModalOpen}
          onClose={() => setConsultModalOpen(false)}
          analysis={analysisResult}
          documentName={documentName || 'Document Audit'}
          userLocation={userLocation}
          onOpenLocationChange={() => setLocationModalOpen(true)}
        />
      )}

      {/* Location Selector Modal */}
      <LocationSelectorModal
        isOpen={locationModalOpen}
        onClose={() => setLocationModalOpen(false)}
        onLocationSelected={(loc) => setUserLocation(loc)}
      />
    </div>
  );
}
