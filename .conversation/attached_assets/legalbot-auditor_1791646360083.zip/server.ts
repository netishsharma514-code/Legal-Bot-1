import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';
import mammoth from 'mammoth';
import { GoogleGenAI } from '@google/genai';

const require = createRequire(import.meta.url);
const pdfParseModule = require('pdf-parse');

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '10mb' }));

// Server-side Google GenAI initialization
const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey
  ? new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    aiEnabled: Boolean(ai),
    timestamp: new Date().toISOString(),
  });
});

// Legal Chat endpoint powered by Gemini 3.8 Flash
app.post('/api/chat', async (req, res) => {
  try {
    const { message, matchedSections = [], history = [] } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message is required' });
    }

    if (!ai) {
      return res.status(503).json({
        error: 'Gemini API is not configured on the server. Falling back to statutory engine.',
        fallback: true,
      });
    }

    const sectionsContext = Array.isArray(matchedSections) && matchedSections.length > 0
      ? `\n\nRELEVANT INDIAN STATUTORY PROVISIONS IDENTIFIED BY LOCAL ENGINE:\n` +
        matchedSections.map((s: { number: string; act: string; title: string; penalty?: string; bailable?: boolean; cognizable?: boolean }) => 
          `- ${s.act} Section ${s.number}: ${s.title} (${s.cognizable ? 'Cognizable' : 'Non-Cognizable'}, ${s.bailable ? 'Bailable' : 'Non-Bailable'})\n  Penalty: ${s.penalty || 'As prescribed'}`
        ).join('\n')
      : '';

    const systemInstruction = `You are "Nyaya Sahayak" (LegalBot), an expert and compassionate Indian Legal Assistant.
Your mission is to understand the user's exact legal intent and provide a structured, source-linked legal answer grounded in Indian Law.

### AUTOMATIC LANGUAGE MATCHING (MANDATORY RULE):
You must detect the user's language and respond entirely in the same language throughout all sections:
1. **Hinglish in Roman script** -> Natural, clear Hinglish in Roman script.
2. **English** -> Professional, accessible English.
3. **Hindi in Devanagari script** -> Respectful, clear Hindi in Devanagari script.
4. If the user explicitly requests another language, use that language.

### STRUCTURE OF EVERY ANSWER (MANDATORY 4-SECTION FORMAT):
Every legal response MUST contain these distinct, clearly separated sections:

### 1. Quick Answer
- Directly and concisely answer the user's actual question in the very first sentence. Do not start with generic boilerplate.
- Identify the main legal issue and mention potentially applicable offences, rights, or remedies.
- Cite relevant statutory provisions when reliably identified.
- Note that statutory applicability depends on the specific factual circumstances.
- For sensitive disclosures (e.g. sexual violence or trauma), respond with profound empathy, reassurance that they are not to blame, and prioritize immediate safety and medical assistance.

### 2. Detailed Explanation
- Explain the legal issue in simple, accessible language.
- Discuss possible offences, consequences, rights, procedural requirements (e.g., FIR/Zero FIR, 15-day cheque notice, civil injunctions).
- Provide practical next steps (evidence preservation, police escalation, statutory timelines).
- Avoid irrelevant legal filler.

### 3. Applicable Laws and Sections
For every relevant legal provision, provide a distinct block:
- **Act Name**: Full official name (e.g., Bharatiya Nyaya Sanhita, 2023 / Negotiable Instruments Act, 1881 / IT Act, 2000).
- **Section Number**: Exact section (include historic IPC/CrPC equivalent if criminal law).
- **Explanation**: Concise explanation in the user's matched language.
- **Why It Applies**: How it connects to the situation.
- **Conditions or Limitations**: Procedural prerequisites, bailability, cognizable status, or limitation periods.
- **Official Source Link**: Link to official legislation on India Code (e.g. https://www.indiacode.nic.in/). Never invent section numbers or case citations.

### 4. Official Sources
Provide direct links to official legislation and government services:
- India Code (https://www.indiacode.nic.in/)
- National Legal Services Authority - NALSA (https://nalsa.gov.in/) & Helpline 15100
- National Cyber Crime Reporting Portal (https://cybercrime.gov.in/) & Helpline 1930
- National Emergency 112 / Women Helpline 1090 where applicable.

Conclude with a brief standard disclaimer in the matched language stating that the guidance is for informational awareness and does not replace registered advocate counsel.`;

    const chatHistoryContext = Array.isArray(history) && history.length > 0
      ? history.slice(-6).map((h: { sender: string; text: string }) => `${h.sender === 'user' ? 'User' : 'Assistant'}: ${h.text}`).join('\n') + '\n\n'
      : '';

    const promptText = `${chatHistoryContext}User Inquiry: ${message}${sectionsContext}`;

    const response = await Promise.race([
      ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: promptText,
        config: {
          systemInstruction,
          temperature: 0.2,
        },
      }),
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error('AI response timed out')), 35000)
      ),
    ]);

    const reply = response.text || 'Unable to generate response. Please consult statutory lookup.';
    return res.json({ reply, source: 'gemini-3.8-flash' });
  } catch (error) {
    console.error('Error generating AI response:', error);
    return res.status(500).json({
      error: 'Failed to generate legal guidance from AI engine',
      details: error instanceof Error ? error.message : String(error),
      fallback: true,
    });
  }
});

// Text extraction endpoint for PDF, DOCX, and TXT files
app.post('/api/extract-document-text', async (req, res) => {
  try {
    const { base64, filename, mimeType } = req.body;

    if (!base64 || typeof base64 !== 'string') {
      return res.status(400).json({ error: 'Document data (base64) is required.' });
    }

    const cleanBase64 = base64.replace(/^data:[^;]+;base64,/, '');
    const buffer = Buffer.from(cleanBase64, 'base64');

    // 10MB size limit validation
    if (buffer.length > 10 * 1024 * 1024) {
      return res.status(413).json({
        error: 'File size exceeds the 10MB limit. Please upload a smaller document.',
      });
    }

    const ext = path.extname(filename || '').toLowerCase();
    let extractedText = '';

    if (ext === '.pdf' || mimeType === 'application/pdf') {
      try {
        const { PDFParse } = pdfParseModule || {};
        if (typeof PDFParse === 'function') {
          const parser = new PDFParse({ data: buffer });
          const result = await parser.getText();
          extractedText = typeof result === 'string' ? result : (result?.text || '');
        } else if (typeof pdfParseModule === 'function') {
          const result = await pdfParseModule(buffer);
          extractedText = result?.text || '';
        } else {
          return res.status(500).json({ error: 'PDF parsing engine unavailable on server.' });
        }
      } catch (pdfErr) {
        console.error('PDF Parse error:', pdfErr);
        return res.status(422).json({
          error: 'Unable to read PDF. The file may be password-encrypted, corrupted, or incompatible. Please upload an unencrypted file or paste the text directly.',
        });
      }
    } else if (ext === '.docx' || mimeType?.includes('wordprocessingml') || ext === '.doc') {
      try {
        const docResult = await mammoth.extractRawText({ buffer });
        extractedText = docResult.value || '';
      } catch (docxErr) {
        console.error('DOCX Parse error:', docxErr);
        return res.status(422).json({
          error: 'Unable to read DOCX file. The document may be corrupted or password-protected. Please upload a standard .docx or paste text directly.',
        });
      }
    } else if (ext === '.txt' || mimeType === 'text/plain') {
      extractedText = buffer.toString('utf-8');
    } else {
      return res.status(400).json({
        error: `Unsupported file type "${ext || 'unknown'}". Supported formats are PDF, DOCX, and TXT.`,
      });
    }

    const trimmed = extractedText.trim();

    // Check if document is scanned (empty text) or unreadable
    if (!trimmed || trimmed.length < 20) {
      return res.status(422).json({
        error: 'The uploaded file appears to be a scanned image-only PDF, encrypted, or empty. Optical Character Recognition (OCR) is required for scanned paper copies. Please upload a document with selectable text or copy and paste the text directly into the audit box.',
        isScannedOrUnreadable: true,
      });
    }

    return res.json({
      success: true,
      filename: filename || 'Uploaded Document',
      text: trimmed,
      characterCount: trimmed.length,
      estimatedWords: trimmed.split(/\s+/).length,
    });
  } catch (error) {
    console.error('Document extraction error:', error);
    return res.status(500).json({
      error: 'Failed to process document file on server.',
      details: error instanceof Error ? error.message : String(error),
    });
  }
});

// Legal Document Analysis endpoint
app.post('/api/analyze-document', async (req, res) => {
  const { documentText, documentName } = req.body || {};

  if (!documentText || typeof documentText !== 'string') {
    return res.status(400).json({ error: 'Document text is required for analysis' });
  }

  if (!ai) {
    const fallback = generateFallbackAudit(documentText, documentName);
    return res.json({ analysis: fallback, source: 'statutory-engine' });
  }

  try {

    const systemInstruction = `You are a Senior Indian Legal Document Auditor and Contract Specialist.
Your mission is to perform a rigorous, objective, and legally grounded audit of the provided agreement under Indian law (including the Indian Contract Act 1872, Arbitration and Conciliation Act 1996, Transfer of Property Act 1882, Specific Relief Act 1963, Information Technology Act 2000, and Supreme Court jurisprudence).

### CRITICAL ACCURACY & GROUNDING RULES:
1. STRICTLY DISTINGUISH EXTRACTED FACTS FROM AI-GENERATED INTERPRETATIONS:
   - "extractedFacts" must contain ONLY factual clauses, dates, parties, and obligations directly stated in the text.
   - Never invent or fabricate clauses, parties, dates, or terms not present in the draft. If a party or date is missing, state "Not specified in document".
2. ACCURATE STATUTORY CITATIONS:
   - Cite genuine Indian statutory provisions (e.g. Section 27 Indian Contract Act for non-compete voidness; Section 73 & 74 for damages and liquidated damages; Perkins Eastman Architects (2019) for sole arbitrator appointment invalidity; Section 106 Transfer of Property Act for lease termination notices; Section 138 Negotiable Instruments Act for cheque liabilities).
   - Never invent non-existent section numbers or acts.
3. PLAIN LANGUAGE EXPLANATION:
   - Explain the core implications simply and clearly so any ordinary citizen or business owner can understand their commitments and liabilities.

You must respond ONLY with valid JSON conforming strictly to this structure:
{
  "documentType": "e.g. Residential Rental Agreement / Employment Agreement / Non-Disclosure Agreement / Commercial Service Contract / Vendor Agreement / Loan Agreement",
  "subject": "1-2 sentence core subject matter of the agreement",
  "summary": "2-3 sentence objective overview of the document scope and terms.",
  "plainLanguageExplanation": "Clear, jargon-free explanation for a non-lawyer explaining what this agreement means for them in practical life.",
  "riskScore": 45, // Number 0 to 100 where 0 is safest and 100 is critical risk
  "riskLevel": "Medium", // "Low", "Medium", or "High"
  "governingLawCompliance": "Evaluation of governing law, jurisdiction, and court forum under Indian territory.",
  "extractedFacts": {
    "documentType": "e.g. Employment and Service Agreement",
    "subject": "Employment terms and post-termination covenants",
    "parties": [
      { "role": "Employer / Company", "name": "Company Name or [Party A]" },
      { "role": "Employee", "name": "Employee Name or [Party B]" }
    ],
    "importantDates": [
      { "label": "Execution / Effective Date", "dateOrPeriod": "e.g. 1st March 2026" },
      { "label": "Notice Period", "dateOrPeriod": "e.g. 30 days written notice" }
    ],
    "keyObligations": [
      "e.g. Employee must maintain confidentiality of proprietary trade secrets",
      "e.g. Company must pay monthly salary by 7th of every month"
    ],
    "importantClauses": [
      {
        "clauseTitle": "e.g. Confidentiality Obligation",
        "originalTextSnippet": "Verbatim quote or short clause snippet from text",
        "purpose": "Protects company non-public data and customer records"
      }
    ]
  },
  "flaggedClauses": [
    {
      "clauseTitle": "e.g. Post-Employment Non-Compete",
      "severity": "High", // "Low", "Medium", or "High"
      "issue": "Specific explanation of why this clause creates risk or is void under Section 27 Indian Contract Act 1872.",
      "recommendation": "Concrete redline or amendment advice to balance or rectify the clause.",
      "relevantLaw": "Section 27, Indian Contract Act 1872; Percept D'Mark v. Zaheer Khan (2006)"
    }
  ],
  "missingProtections": [
    "e.g. Mutual limitation of liability cap is missing",
    "e.g. Institutional arbitration clause is absent"
  ],
  "positiveAspects": [
    "e.g. Reciprocal 30-day written notice for convenience termination"
  ],
  "recommendedNextSteps": [
    "e.g. Request mutual amendment of the unilateral indemnity clause prior to execution",
    "e.g. Ensure document is executed on requisite Non-Judicial Stamp Paper under State Stamp Act"
  ],
  "officialSources": [
    {
      "title": "Indian Contract Act, 1872 (India Code)",
      "statute": "Act No. 9 of 1872",
      "url": "https://www.indiacode.nic.in/handle/123456789/2187",
      "relevance": "Section 27 renders agreements in restraint of trade void; Sections 73-74 govern compensation for breach."
    },
    {
      "title": "Arbitration and Conciliation Act, 1996",
      "statute": "Act No. 26 of 1996",
      "url": "https://www.indiacode.nic.in/handle/123456789/1978",
      "relevance": "Section 12(5) governs independence of arbitrators and bars unilateral appointment."
    }
  ]
}`;

    const promptText = `Document Name: ${documentName || 'Uploaded Legal Document'}\n\nDocument Text:\n${documentText.slice(0, 15000)}`;

    const response = await Promise.race([
      ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: promptText,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          temperature: 0.1,
        },
      }),
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error('AI response timed out')), 12000)
      ),
    ]);

    const parsedData = JSON.parse(response.text || '{}');
    if (parsedData && parsedData.summary) {
      return res.json({ analysis: parsedData, source: 'gemini-3.8-flash' });
    }
    // If output is malformed, use statutory engine
    const fallback = generateFallbackAudit(documentText, documentName);
    return res.json({ analysis: fallback, source: 'statutory-engine' });
  } catch (error) {
    console.warn('Gemini model unavailable, falling back to statutory audit engine:', error);
    const fallback = generateFallbackAudit(documentText, documentName);
    return res.json({
      analysis: fallback,
      source: 'statutory-engine',
      notice: 'Analyzed using the deterministic Indian statutory audit engine.',
    });
  }
});

function generateFallbackAudit(text: string, title?: string) {
  const lower = (text || '').toLowerCase();
  const flagged = [];
  let score = 25;

  let docType = 'Commercial Agreement';
  if (lower.includes('rent') || lower.includes('lease') || lower.includes('tenan')) {
    docType = 'Residential Rental Agreement';
  } else if (lower.includes('employ') || lower.includes('service agreement')) {
    docType = 'Employment & Service Agreement';
  } else if (lower.includes('nda') || lower.includes('non-disclosure') || lower.includes('confidential')) {
    docType = 'Non-Disclosure Agreement (NDA)';
  } else if (lower.includes('loan') || lower.includes('promissory')) {
    docType = 'Loan Agreement & Promissory Deed';
  }

  if (lower.includes('non-compete') || lower.includes('competing business')) {
    flagged.push({
      clauseTitle: 'Post-Termination Non-Compete Restriction',
      severity: 'High',
      issue: 'Agreements in restraint of trade, profession, or lawful business are void under Section 27 of the Indian Contract Act, 1872.',
      recommendation: 'Post-employment non-compete clauses are legally unenforceable in Indian courts. Replace with a narrow confidentiality and non-solicitation covenant.',
      relevantLaw: 'Section 27, Indian Contract Act 1872; Percept D\'Mark v. Zaheer Khan (2006)',
    });
    score += 35;
  }

  if (lower.includes('indemnif') && (lower.includes('solely') || lower.includes('unilateral') || lower.includes('irrespective') || lower.includes('directors'))) {
    flagged.push({
      clauseTitle: 'Unilateral & Unlimited Indemnification Exposure',
      severity: 'High',
      issue: 'Exposes one party to uncapped financial liabilities without reciprocal protection or aggregate liability cap.',
      recommendation: 'Cap maximum aggregate liability to fees received or reasonable insurance coverage, and exclude indirect or consequential damages.',
      relevantLaw: 'Section 73, Indian Contract Act 1872',
    });
    score += 25;
  }

  if (lower.includes('without cause') && (lower.includes('without any notice') || lower.includes('immediately'))) {
    flagged.push({
      clauseTitle: 'Immediate Termination Without Notice or Severance',
      severity: 'Medium',
      issue: 'Deprives signatory of customary transition period and fair cure notice.',
      recommendation: 'Insert mandatory reciprocal 30-day written notice period for convenience termination.',
      relevantLaw: 'Principles of Natural Justice & Commercial Practice',
    });
    score += 15;
  }

  if (lower.includes('appointed solely') || lower.includes('sole arbitrator appointed by') || lower.includes('solely by the company')) {
    flagged.push({
      clauseTitle: 'Unilateral Appointment of Sole Arbitrator',
      severity: 'High',
      issue: 'A party having an interest in the dispute cannot unilaterally appoint a sole arbitrator under Supreme Court ruling in Perkins Eastman (2019).',
      recommendation: 'Mandate mutual consent of both parties for arbitrator nomination or appointment through the High Court Arbitration Centre.',
      relevantLaw: 'Perkins Eastman Architects v. HSCC (India) Ltd (2019); Section 12(5) Arbitration Act 1996',
    });
    score += 20;
  }

  if (lower.includes('outside the territory of india') || lower.includes('foreign court')) {
    flagged.push({
      clauseTitle: 'Ouster of Indian Court Jurisdiction',
      severity: 'High',
      issue: 'Agreements executed between Indian parties within India cannot exclude Indian court jurisdiction.',
      recommendation: 'Specify exclusive jurisdiction of Indian civil courts where the cause of action arises.',
      relevantLaw: 'Section 28, Indian Contract Act 1872',
    });
    score += 20;
  }

  const finalScore = Math.min(score, 95);
  const riskLevel = finalScore > 65 ? 'High' : finalScore > 40 ? 'Medium' : 'Low';

  const parties = [];
  if (lower.includes('landlord') || lower.includes('lessor')) parties.push({ role: 'Lessor / Landlord', name: 'Landlord party' });
  if (lower.includes('tenant') || lower.includes('lessee')) parties.push({ role: 'Lessee / Tenant', name: 'Tenant party' });
  if (lower.includes('employer') || lower.includes('company')) parties.push({ role: 'Employer / Company', name: 'First Party (Employer)' });
  if (lower.includes('employee')) parties.push({ role: 'Employee', name: 'Second Party (Employee)' });
  if (parties.length === 0) parties.push({ role: 'Contracting Parties', name: 'Parties executing draft' });

  const dates = [];
  const dateMatch = text.match(/\b\d{1,2}(?:st|nd|rd|th)?\s+(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{4}\b/i);
  if (dateMatch) dates.push({ label: 'Execution / Effective Date', dateOrPeriod: dateMatch[0] });
  if (lower.includes('11-month') || lower.includes('11 month')) dates.push({ label: 'Term Duration', dateOrPeriod: '11 Months' });
  if (lower.includes('notice')) dates.push({ label: 'Termination Notice', dateOrPeriod: '30 Days prior written notice' });
  if (dates.length === 0) dates.push({ label: 'Effective Term', dateOrPeriod: 'As stipulated in agreement schedule' });

  return {
    documentType: docType,
    subject: `Audit of ${docType} under Indian statutory frameworks`,
    summary: `Audited legal draft against the Indian Contract Act 1872 and commercial jurisprudence. Identified ${flagged.length} potential legal exposures.`,
    plainLanguageExplanation: `This agreement establishes binding legal obligations. Important clauses regarding financial indemnification, dispute resolution, and post-termination restrictions should be revised prior to execution.`,
    riskScore: finalScore,
    riskLevel,
    governingLawCompliance: 'Evaluated under Indian Contract Act 1872, Arbitration Act 1996, and Transfer of Property Act 1882.',
    extractedFacts: {
      documentType: docType,
      subject: `Terms and conditions in ${title || 'Legal Document'}`,
      parties,
      importantDates: dates,
      keyObligations: [
        'Performance of covenants and duties specified in clauses',
        'Compliance with payment and notice timelines',
      ],
      importantClauses: [
        {
          clauseTitle: 'Primary Operative Covenants',
          originalTextSnippet: text.slice(0, 120) + '...',
          purpose: 'Defines operational terms and signatory commitments',
        },
      ],
    },
    flaggedClauses: flagged,
    missingProtections: [
      'Mutual limitation of liability aggregate cap',
      'Standard Force Majeure relief clause',
      'Balanced dispute resolution and mediation clause',
    ],
    positiveAspects: [
      'Execution date and party identities are clearly identifiable.',
    ],
    recommendedNextSteps: [
      'Request mutual revision of flagged high-risk clauses prior to signing.',
      'Verify required Non-Judicial Stamp Duty under applicable State Stamp Act.',
      'Consult a verified advocate in your city for formal redline drafting.',
    ],
    officialSources: [
      {
        title: 'Indian Contract Act, 1872',
        statute: 'Act No. 9 of 1872',
        url: 'https://www.indiacode.nic.in/handle/123456789/2187',
        relevance: 'Section 27 renders agreements in restraint of trade void; Sections 73-74 govern compensation for breach.',
      },
      {
        title: 'Arbitration and Conciliation Act, 1996',
        statute: 'Act No. 26 of 1996',
        url: 'https://www.indiacode.nic.in/handle/123456789/1978',
        relevance: 'Section 12(5) bars unilateral appointment of sole arbitrators.',
      },
    ],
  };
}

// Mount Vite or static files
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Legal Bot server running on http://0.0.0.0:${port}`);
  });
}

startServer();
